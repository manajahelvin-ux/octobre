/* Formulaire multi-étapes + bandeau cookies
   - Aucune donnée n'est envoyée tant que CONFIG.endpoint est vide (mode démonstration).
   - Pour recevoir les demandes : renseignez une URL d'API (Formspree, Make, Zapier, votre serveur...). */
(function () {
  'use strict';

  var CONFIG = {
    endpoint: '',           // ex. 'https://formspree.io/f/xxxxxxx'
    source: 'LP CONSULTANTS',
    categorie: 'RC PRO - MULTIRISQUE'
  };

  /* ---------- Formulaire ---------- */
  var form = document.getElementById('leadForm');
  if (form) {
    var steps = Array.prototype.slice.call(form.querySelectorAll('.step[data-step]'))
      .filter(function (s) { return s.getAttribute('data-step') !== 'done'; });
    var done = form.querySelector('.step-done');
    var prev = document.getElementById('prev');
    var next = document.getElementById('next');
    var bar = document.getElementById('bar');
    var count = document.getElementById('stepCount');
    var nav = document.getElementById('nav');
    var formError = document.getElementById('formError');
    var current = 0;
    var sending = false;

    function render() {
      steps.forEach(function (s, k) { s.classList.toggle('is-active', k === current); });
      bar.style.width = ((current + 1) / steps.length * 100) + '%';
      count.textContent = 'Étape ' + (current + 1) + ' sur ' + steps.length;
      prev.disabled = current === 0;
      next.textContent = current === steps.length - 1 ? 'Envoyer ma demande' : 'Suivant';
      formError.textContent = '';
    }

    function isValid() {
      var s = steps[current];
      var err = s.querySelector('[data-err]');
      if (err) err.textContent = '';
      var key = s.getAttribute('data-step');

      if (key === '1') {
        if (!s.querySelector('input[type=checkbox]:checked')) {
          err.textContent = 'Sélectionnez au moins un type d\'assurance.';
          return false;
        }
        return true;
      }
      if (key === '7') {
        var email = form.email.value.trim();
        var tel = form.telephone.value.trim();
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { err.textContent = 'Adresse e-mail invalide.'; return false; }
        if (!tel) { err.textContent = 'Indiquez un numéro de téléphone.'; return false; }
        if (!form.consent.checked) { err.textContent = 'Veuillez accepter les conditions pour continuer.'; return false; }
        return true;
      }
      if (!s.querySelector('input[type=radio]:checked')) {
        err.textContent = 'Veuillez faire un choix.';
        return false;
      }
      return true;
    }

    function collect() {
      var data = {
        source: CONFIG.source,
        categorie: CONFIG.categorie,
        date: new Date().toISOString()
      };
      var fd = new FormData(form);
      fd.forEach(function (v, k) {
        if (k === 'consent') return;
        if (data[k]) { data[k] = data[k] + ', ' + v; } else { data[k] = v; }
      });
      data.consent = form.consent.checked ? 'oui' : 'non';
      return data;
    }

    function showDone() {
      steps.forEach(function (s) { s.classList.remove('is-active'); });
      done.classList.add('is-active');
      nav.style.display = 'none';
      bar.style.width = '100%';
      count.textContent = 'Demande envoyée';
    }

    function submit() {
      if (sending) return;
      var data = collect();
      if (!CONFIG.endpoint) {
        // Mode démonstration : affiche la confirmation sans envoyer
        console.info('Demande (mode démo, non envoyée) :', data);
        showDone();
        return;
      }
      sending = true;
      next.disabled = true;
      next.textContent = 'Envoi…';
      fetch(CONFIG.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(data)
      }).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        showDone();
      }).catch(function () {
        formError.textContent = 'Une erreur est survenue lors de l\'envoi. Merci de réessayer.';
        next.disabled = false;
        next.textContent = 'Envoyer ma demande';
      }).finally(function () { sending = false; });
    }

    next.addEventListener('click', function () {
      if (!isValid()) return;
      if (current < steps.length - 1) { current++; render(); }
      else { submit(); }
    });

    prev.addEventListener('click', function () {
      if (current > 0) { current--; render(); }
    });

    // Touche Entrée : passe à l'étape suivante (sauf dans les champs texte pour le dernier envoi)
    form.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
        e.preventDefault();
        next.click();
      }
    });

    render();
  }

  /* ---------- Bandeau cookies ---------- */
  var banner = document.getElementById('cookies');
  var manage = document.getElementById('manageCookies');
  var KEY = 'cookiesChoice';

  function setChoice(value) {
    try { localStorage.setItem(KEY, value); } catch (e) {}
    if (banner) banner.hidden = true;
  }

  if (banner) {
    var saved = null;
    try { saved = localStorage.getItem(KEY); } catch (e) {}
    banner.hidden = !!saved;

    banner.querySelectorAll('[data-cookie]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        setChoice(btn.getAttribute('data-cookie'));
      });
    });
  }

  if (manage && banner) {
    manage.addEventListener('click', function (e) {
      e.preventDefault();
      banner.hidden = false;
    });
  }
})();
